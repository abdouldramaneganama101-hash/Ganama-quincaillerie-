# Ganama Quincaillerie

Application Android simple pour présenter les produits et préparer une commande.

## Construction
Le workflow GitHub Actions `.github/workflows/build-apk.yml` construit automatiquement `app-debug.apk` avec Java 17, Android SDK 36 et Gradle 8.13.

Les images de démonstration sont intégrées directement dans `app/src/main/assets/images/`, donc l'application peut démarrer sans connexion Internet.

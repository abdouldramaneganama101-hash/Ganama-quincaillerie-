# Ganama Quincaillerie — test complet

Le workflow `.github/workflows/build-apk.yml` effectue une vérification complète avant de publier l'APK :

1. structure du projet ;
2. configuration Gradle/SDK/Java ;
3. `MainActivity` ;
4. `AndroidManifest` et `MAIN/LAUNCHER` ;
5. XML ;
6. WebView, HTML et images locales ;
7. syntaxe JavaScript ;
8. compilation réelle ;
9. identité de l'APK avec `aapt` ;
10. installation et démarrage sur un émulateur Android.

L'APK n'est publié que si toutes les étapes précédentes réussissent.

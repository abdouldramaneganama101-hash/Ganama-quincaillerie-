package com.ganama.quincaillerie;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView header = new TextView(this);
        header.setText("GANAMA QUINCAILLERIE");
        header.setTextColor(Color.WHITE);
        header.setTextSize(22);
        header.setGravity(Gravity.CENTER);
        header.setTypeface(null, 1);
        header.setPadding(dp(12), dp(18), dp(12), dp(18));
        header.setBackgroundColor(Color.rgb(11,61,145));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(12), dp(12), dp(12), dp(20));

        TextView intro = new TextView(this);
        intro.setText("Matériel et équipements\nChoisissez un produit");
        intro.setTextSize(18);
        intro.setTextColor(Color.DKGRAY);
        intro.setPadding(dp(4), dp(4), dp(4), dp(12));
        list.addView(intro);

        addProduct(list, "Aspirateur / souffleur", "Aspirateur 2-en-1", com.ganama.quincaillerie.R.drawable.ic_aspirateur);
        addProduct(list, "Tondeuse", "Tondeuse à cheveux", com.ganama.quincaillerie.R.drawable.ic_tondeuse);
        addProduct(list, "Extincteur", "Matériel de sécurité", com.ganama.quincaillerie.R.drawable.ic_extincteur);
        addProduct(list, "Compresseur", "Compresseur polyvalent", com.ganama.quincaillerie.R.drawable.ic_compresseur);
        addProduct(list, "Rallonge", "Rallonge électrique", com.ganama.quincaillerie.R.drawable.ic_rallonge);

        TextView footer = new TextView(this);
        footer.setText("Ganama Quincaillerie\nVotre matériel, simplement.");
        footer.setGravity(Gravity.CENTER);
        footer.setTextSize(16);
        footer.setTextColor(Color.rgb(11,61,145));
        footer.setPadding(0, dp(20), 0, dp(20));
        list.addView(footer);

        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void addProduct(LinearLayout parent, String title, String subtitle, int image) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        card.setBackgroundColor(Color.rgb(245,247,250));

        ImageView icon = new ImageView(this);
        icon.setImageResource(image);
        icon.setContentDescription(title);
        card.addView(icon, new LinearLayout.LayoutParams(dp(92), dp(92)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(dp(14), 0, 0, 0);
        TextView t = new TextView(this); t.setText(title); t.setTextSize(18); t.setTextColor(Color.rgb(11,61,145)); t.setTypeface(null,1);
        TextView s = new TextView(this); s.setText(subtitle); s.setTextSize(14); s.setTextColor(Color.DKGRAY);
        texts.addView(t); texts.addView(s);
        card.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        parent.addView(card, new LinearLayout.LayoutParams(-1, dp(116)));
        View spacer = new View(this); parent.addView(spacer, new LinearLayout.LayoutParams(1, dp(8)));
    }
}

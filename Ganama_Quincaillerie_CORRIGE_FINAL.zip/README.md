# Ganama Quincaillerie

Projet Android WebView avec contenu local.

## Corrections appliquées
- Correction de la déclaration `package` de `MainActivity.java`.
- Vérification du manifeste et de l'activité `MAIN`/`LAUNCHER`.
- Vérification des ressources, de l'icône et du contenu WebView local.
- Workflow GitHub Actions remplacé par une vraie compilation Gradle 8.13 avec Java 17.
- Vérification automatique de l'existence de l'APK avant publication.

## Construction
Le workflow `.github/workflows/build-apk.yml` installe l'environnement Android puis produit :
`app/build/outputs/apk/debug/app-debug.apk`.

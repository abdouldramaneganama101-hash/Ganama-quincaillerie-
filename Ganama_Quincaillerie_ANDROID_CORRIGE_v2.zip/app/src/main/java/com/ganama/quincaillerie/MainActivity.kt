package com.ganama.quincaillerie

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView

class MainActivity : Activity() {
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openApp()
    }

    private fun openApp() {
        try {
            val web = WebView(this)
            webView = web

            web.settings.javaScriptEnabled = true
            web.settings.domStorageEnabled = true
            web.settings.allowFileAccess = true
            web.settings.allowContentAccess = true
            web.settings.databaseEnabled = true
            web.settings.loadsImagesAutomatically = true
            web.settings.javaScriptCanOpenWindowsAutomatically = false
            web.webChromeClient = WebChromeClient()
            web.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
            }

            web.setBackgroundColor(Color.WHITE)
            web.loadUrl("file:///android_asset/index.html")

            setContentView(web)
        } catch (e: Throwable) {
            showFallback(e)
        }
    }

    private fun showFallback(error: Throwable) {
        val message = TextView(this).apply {
            text = "Ganama Quincaillerie\n\nL'application a rencontré un problème au démarrage.\n\n${error.javaClass.simpleName}"
            textSize = 18f
            setTextColor(Color.DKGRAY)
            setPadding(40, 60, 40, 40)
        }
        setContentView(message)
    }

    override fun onDestroy() {
        webView?.apply {
            stopLoading()
            webChromeClient = null
            webViewClient = null
            destroy()
        }
        webView = null
        super.onDestroy()
    }
}

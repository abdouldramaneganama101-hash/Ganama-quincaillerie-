# Ganama Quincaillerie

Projet Android WebView avec contenu local.

## Vérifications effectuées
- structure Gradle et module `app`
- activité principale et WebView
- manifeste Android
- `index.html`
- ressources d'images
- workflow GitHub Actions
- archive ZIP finale
